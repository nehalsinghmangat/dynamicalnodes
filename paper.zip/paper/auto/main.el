;; -*- lexical-binding: t; -*-

(TeX-add-style-hook
 "main"
 (lambda ()
   (setq TeX-command-extra-options
         "-shell-escape")
   (TeX-add-to-alist 'LaTeX-provided-class-options
                     '(("IEEEtran" "conference")))
   (TeX-add-to-alist 'LaTeX-provided-package-options
                     '(("natbib" "numbers")))
   (add-to-list 'LaTeX-verbatim-environments-local "lstlisting")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "lstinline")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "path")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "url")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "nolinkurl")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "hyperbaseurl")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "hyperimage")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "href")
   (add-to-list 'LaTeX-verbatim-macros-with-delims-local "lstinline")
   (add-to-list 'LaTeX-verbatim-macros-with-delims-local "path")
   (TeX-run-style-hooks
    "latex2e"
    "IEEEtran"
    "IEEEtran10"
    "amsmath"
    "amssymb"
    "amsfonts"
    "graphicx"
    "textcomp"
    "bm"
    "xcolor"
    "soul"
    "tikz"
    "listings"
    "booktabs"
    "subcaption"
    "caption"
    "float"
    "stfloats"
    "hyperref"
    "subfiles"
    "natbib")
   (LaTeX-add-labels
    "sec:intro"
    "sec:background"
    "subsec:dynamical_systems"
    "eq:CTDS"
    "eq:DTDS"
    "eq:def_fh"
    "eq:def_fh_passthrough"
    "eq:def_fh_stateless"
    "subsubsec:car_with_speed"
    "subsubsec:signal_generators"
    "subsubsec:composing_dynamical_systems"
    "subsec:control_diagrams"
    "fig:dtds_feedback"
    "fig:ros_graph"
    "sec:framework"
    "subsec:overview"
    "fig:framework_theory"
    "fig:framework_python"
    "fig:framework_ros"
    "fig:framework"
    "subsec:dynamicalsystemclass"
    "fig:code_car_dynamics"
    "subsec:rosnodeclass"
    "fig:ros_car_dynamics"
    "subsec:rosdatahandling"
    "fig:modular"
    "fig:translationfun"
    "fig:state_output"
    "fig:syncmode_any"
    "fig:syncmode_all"
    "sec:example_cruise_control"
    "subsec:plant_example"
    "fig:plant_fh_code"
    "subsec:pid_example"
    "fig:pid_fh_code"
    "subsec:kf_example"
    "fig:kf"
    "subsec:cruise_simulation"
    "fig:cruise_python_loop"
    "fig:python_output"
    "fig:cruise_ros_loop"
    "fig:rqt_graph"
    "fig:ros_output"
    "sec:related"
    "sec:conclusion")
   (LaTeX-add-bibliographies
    "references"))
 :latex)

